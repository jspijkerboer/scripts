﻿<#
.SYNOPSIS
    Script to rerun a deployment step on a Dynamics365 Finance & Operations Enterprise Edition VM
#>
param(
	[string] $Directory = $null,
	[string] $ScriptsDirectory = $null,
	[Parameter(Mandatory=$true)]
	[string] $BuildNumber = $null,
	[Parameter(Mandatory=$true)]
	[int] $step
)

trap
{
    write-host "Errors found"
    write-host $_
    exit 1
}

$ErrorActionPreference = "Stop"

<#
.SYNOPSIS
    Runs AxUpdateInstaller.exe
#>
function Execute-Installer([string]$executeArgs, [string]$packageDirectory)
{

    $deploymentPath = [string]::Format("{0}", $Directory)
    $installerFile = [string]::Format("{0}\{1}", $packageDirectory, "AxUpdateInstaller.exe")

    $installerInfo = New-Object System.Diagnostics.ProcessStartInfo
    $installerInfo.FileName = $installerFile
    $installerInfo.RedirectStandardOutput = $true
    $installerInfo.UseShellExecute = $false
    $installerInfo.Arguments = $executeArgs

    $installer = New-Object System.Diagnostics.Process
    $installer.StartInfo = $installerInfo
    $installer.Start() | Out-Null

    $stdout = $installer.StandardOutput.ReadToEnd()
	write-host $stdout
	Analyze-output($stdout)    
}

function Analyze-output([string]$output)
{
	if ($output.Contains("The step failed") -or $output.Contains("failed state"))
	{
		Write-Error "$($env:ErrorMessage) A deployment step failed"
		throw "Deployment failed" 
	}

	if ($output.Contains("overwrite the existing runbook"))
	{
		Write-Warning "An unfinished deployment exists"
	}
}

$deploymentPath = [string]::Format("{0}", $Directory)
$counter = 0

cd $deploymentPath

$packageDirectory = [string]::Format("{0}\{1}_{2}", $deploymentPath, "package", $counter)

#Generate Runbook
$runbookId = [string]::Format("{0}_{1}", $BuildNumber, $counter)

#Execute
write-host "Executing runbook with rerunstep..."

$args = [string]::Format("execute -runbookId={0} -rerunstep={1}", $runbookId, $step)
Execute-Installer -executeArgs $args -packageDirectory $packageDirectory

write-host "Deployment Complete"

exit 0

